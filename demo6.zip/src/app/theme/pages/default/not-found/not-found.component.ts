import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: '.m-wrapper',
  templateUrl: './not-found.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class NotFoundComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}